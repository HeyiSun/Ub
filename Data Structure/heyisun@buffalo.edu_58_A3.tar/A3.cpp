//
// Original Author: Andrew Hughes (ahughes6@buffalo.edu)
//

#include "A3.hpp"


PairList::Iterator::Iterator():keyVal(0),depVal(0),pairAddr(nullptr){

}
PairList::Iterator::~Iterator(){
    pairAddr=nullptr;
}



PairList::PairList(int numKeys) {
   std::vector<Node*> temp(numKeys,nullptr);
   _keys=temp;
}

PairList::PairList(const PairList &other){
    *this=other;
}

PairList::Node* PairList::deref(Iterator a) {

    if(  a.keyVal>= (a.pairAddr)->_keys.size() ||   a.keyVal<=0 )
        return nullptr;
    Node* cur2=this->_keys[a.keyVal];
    for(int i=0;i<a.depVal-1;i++)
    {
        if(cur2==nullptr)
            return nullptr;
        cur2=cur2->next;
    }
    return cur2;
}
/*PairList* PairList::setPairAddr(){
    return this;
}*/

PairList& PairList::operator=(const PairList &other) {
    if(this!=&other) {
        _keys = other._keys;

        for (int i = 0; i < this->_keys.size(); i++) {
            //Node* cphead=temp[i];
            if (this->_keys[i] == nullptr) {
                continue;
            }
            Node *cur1 = other._keys[i];

            Node *tmpNode = new Node();
            this->_keys[i] = tmpNode;
            tmpNode->value = cur1->value;
            tmpNode->next = nullptr;
            Node *pre = tmpNode;
            tmpNode = nullptr;
            cur1 = cur1->next;

            while (cur1 != nullptr) {
                tmpNode = new Node();
                tmpNode->value = cur1->value;
                tmpNode->next = nullptr;
                pre->next = tmpNode;

                pre = tmpNode;
                tmpNode = nullptr;
                cur1 = cur1->next;
            }

        }
        return *this;
    }
    return *this;
}


PairList::~PairList() {

}

bool PairList::insert(const Pair &pair) {

    if(pair.key>=_keys.size()){
        return false;
    }
    Node* find = _keys[pair.key];
    if(find== nullptr){
        Node* header = new Node();
        header->value=pair.value;
        header->next= nullptr;
        _keys[pair.key]=header;
        return true;
    }
    else if(pair.value<(find->value)){
        Node* temp = new Node();
        temp->value=pair.value;
        temp->next=find;
        _keys[pair.key]=temp;
        return true;
    }
    Node* before = find;
    find=find->next;
    while(find!= nullptr){
        if(before->value==pair.value){
            return false;}
        if(pair.value<find->value){
            Node* temp2 = new Node();
            temp2->value=pair.value;
            temp2->next=find;
            before->next=temp2;
            return true;
        }
        before =find;
        find = find->next; }
    if(before->value==pair.value){
        return false;
    }

    Node* temp3 = new Node();
    temp3->value=pair.value;
    temp3->next=nullptr;
    before->next=temp3;
    return true;
}



bool PairList::contains(const Pair &pair) const {
    if(pair.key>=this->_keys.size()||pair.key<0)
    {
        return false;
    }
    Node *cur4=this->_keys[pair.key];
    while(cur4!=nullptr) {
        if (pair.value == cur4->value) {
        cur4 = nullptr;
        return true;
        }
        cur4=cur4->next;
    }
   cur4=nullptr;
   return false;
}


PairList::Iterator PairList::find(const Pair &pair) {
    if(pair.key>=this->_keys.size()||pair.key<0)
    {
        return end();
    }
    Node* cur5=this->_keys[pair.key];
    Iterator a;
    a.pairAddr=this;
    while(cur5!=nullptr)
    {
        a.depVal++;
        if(pair.value==cur5->value){
            a.keyVal=pair.key;
            cur5=nullptr;
            return a;
        }
        cur5=cur5->next;
    }
    cur5=nullptr;
   return end();
}

bool PairList::remove(const Pair &pair) {
    if(pair.key<0||pair.key>=_keys.size()||contains(pair)==0)
        return false;
    Node* cur8=_keys[pair.key];
    Node* pre=cur8;

    if(cur8->value==pair.value)
    {
        _keys[pair.key]=cur8->next;
        delete cur8;
        pre=nullptr;
        cur8=nullptr;
        return true;
    }
    cur8=_keys[pair.key]->next;
    while(cur8!=nullptr)
    {
        if(cur8->value==pair.value)
        {
            pre->next=cur8->next;
            delete cur8;
            cur8=nullptr;
            pre=nullptr;
            return true;

        }
        pre=cur8;
        cur8=cur8->next;
    }
    return false;
}





PairNode* PairList::associatedList(const int &key) const {
    if(      (key>_keys.size()-1)   ||  key<0  )
        return nullptr;

    Node* cur6 = _keys[key];
    if(cur6==nullptr)
        return nullptr;
    PairNode* pnd = nullptr;
    PairNode* pre = new PairNode(key,cur6->value);
    PairNode* head = pre;
    cur6=cur6->next;

    while(cur6!=nullptr)
    {
        pnd = new PairNode(key,cur6->value);
        pre->next=pnd;
        pre=pre->next;
        cur6=cur6->next;
        pnd=nullptr;
    }
    cur6=nullptr;
    return head;

   return nullptr;
}


PairList::Iterator PairList::begin() {
    Iterator a;
    a.pairAddr=this;
    while((a.pairAddr)->_keys[a.keyVal]==nullptr)
    {
        a.keyVal++;
        if(this->_keys.size()<=a.keyVal){
            a.keyVal=-1;
            a.depVal=-1;
            return a;
        }
    }
    a.depVal=1;

    return a;
}

PairList::Iterator PairList::end() {
    Iterator a;
    a.pairAddr=this;
    int i=0,j=0;
    int m=0;
    while(1) {
        j++;
        for (i = 0; i < _keys.size(); i++) {
            a.keyVal=i;
            a.depVal=j;
            if (deref(a) == nullptr){
                m+=1;
            }
            else{
                m = 0;
            }
            if(m==_keys.size()){
                a.depVal=j-1;
                a.keyVal=i;
                return a;
            }
        }

    }

}

PairList::Iterator& PairList::Iterator::operator++() {
    *this=(this->pairAddr)->begin();
    int i; //index of pointer = nullptr;
    Iterator b = (this->pairAddr)->end();
    if(*this==b){
        this->depVal +=1;
        return *this;
    }

    do{
        if(this->keyVal+1>=(this->pairAddr->_keys).size())
        {
            this->depVal+=1;
            this->keyVal=0;
        }
        else{
            this->keyVal+=1;
        }
    }
    while((this->pairAddr)->deref(*this)==nullptr);

    return *this;
}



PairList::Iterator PairList::Iterator::operator++(int) {
    PairList::Iterator current;
    current.depVal=this->depVal;
    current.keyVal=this->keyVal;
    current.pairAddr=this->pairAddr;

    ++(*this);
   return current;
}


Pair PairList::Iterator::operator*() {
    PairList* p= pairAddr;
    PairList::Node* cur7=p->_keys[keyVal];
    if(cur7==nullptr)
            return Pair(keyVal,0);
    else {
        for (int i = 0; i < depVal - 1; i++) {
            cur7 = cur7->next;
        }
        int value = cur7->value;
        cur7 = nullptr;
        return Pair(keyVal, value);
    }
}



bool PairList::Iterator::operator==(const PairList::Iterator &rhs) const {
   return (rhs.depVal==this->depVal&&rhs.keyVal==this->keyVal&&rhs.pairAddr==this->pairAddr);
}

bool PairList::Iterator::operator!=(const PairList::Iterator &rhs) const {
   return (rhs.depVal!=this->depVal || rhs.keyVal!=this->keyVal || rhs.pairAddr!=this->pairAddr);
}
