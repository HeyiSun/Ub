//
// Name: HeyiSun
//

#include "Stack.hpp"

Stack::Stack(){
    head=nullptr;
    tail=nullptr;
}

Stack::~Stack() {
    if(this->isEmpty()) {
    }
    else {
        while (head != nullptr) {
            DNode *tmp = head;
            head=head->next;
            delete tmp;
        }
    }
}

Stack::Stack(const Stack &other) {
    this->head=nullptr;
    this->tail=nullptr;
    *this=other;
}

Stack& Stack::operator=(const Stack &other) {
    if(this==&other)
        return *this;

    if(other.isEmpty())
    {
        return *this;
    }

  /* if(this->isEmpty()) {
    }
    else {
        while (head != nullptr) {
            DNode *tmp = head;
            head=head->next;
            delete tmp;
        }
    }*/


    DNode* cur2=other.tail;
    while(cur2!=nullptr)
    {
        this->push(cur2->value);
        cur2=cur2->prev;
    }

    return *this;



}



void Stack::push(const Entry &value) {
    if(isEmpty())
    {
        DNode* newNode = new DNode();

        head=newNode;
        tail=newNode;

        newNode->value=value;
        newNode->next=nullptr;
        newNode->prev=nullptr;

        return;
    }
    else{
        DNode* newNode = new DNode();

        DNode* tmp=head;
        head=newNode;

        newNode->value=value;
        newNode->next=tmp;
        newNode->prev=nullptr;
        tmp->prev=head;

        tmp= nullptr;
    }
}

Entry Stack::pop() {
    if(isEmpty())
        throw std::runtime_error( "Pop called on empty stack.");
    else{
        Entry a=head->value;
        DNode* tmp=head;
        head=head->next;

        delete tmp;
        tmp= nullptr;
        if(head!=nullptr)
            head->prev=nullptr;
        if(head==nullptr)
            tail=nullptr;
        return a;
    }
}

Entry Stack::peek() const {
    if(isEmpty())
        throw std::runtime_error( "Peek called on empty stack.");
    else{
        return head->value;
    }
}

bool Stack::isEmpty() const {
    if(head==nullptr&&tail==nullptr)
        return true;
    else
        return false;
}

