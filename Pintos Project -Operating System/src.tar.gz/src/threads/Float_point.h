#ifndef __THREAD_FLOAT_POINT_H
#define __THREAD_FLOAT_POINT_H

typedef int float_point;

#define LEFT_SHIFT 16
#define FLOAT_POINT(A) ((float_point)(A<<LEFT_SHIFT))
#define _ADD(A,B) (A+B)
#define _SUB(A,B) (A-B)
#define _MUL(A,B) ((float_point)(((int64_t) A) * B >> LEFT_SHIFT))
#define _DIV(A,B) ((float_point)((((int64_t) A)<< LEFT_SHIFT)/B))
#define FTOI(A) (A>>LEFT_SHIFT)
#define _MUL_INT(A,B) (A*B)
#define _DIV_INT(A,B) (A/B)
#define _ADD_INT(A,B) (A+(B<<LEFT_SHIFT))
#define _SUB_INT(A,B) (A-(B<<LEFT_SHIFT))



#endif
